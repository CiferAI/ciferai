import math

def circle_area(radius):
    return math.pi * radius ** 2