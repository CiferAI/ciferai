# cifer/module1.py

def greet(name: str) -> str:
    return f"Hello, {name}! Welcome to the Cifer library."